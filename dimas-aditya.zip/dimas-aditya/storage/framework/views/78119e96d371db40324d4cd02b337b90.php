

<?php $__env->startSection('content'); ?>
    <article class="mt-3">
        <h2><?php echo e($isi->title); ?></h2>
        <h5 class="mt-3">By <a class="text-decoration-none" href="#"><?php echo e($isi->user->name); ?></a> In <a
                href="/categories/<?php echo e($isi->category->slug); ?>" class="text-decoration-none"><?php echo e($isi->category->name); ?></a></h5>

        <p><?php echo $isi->body; ?></p>
    </article>
    <a class="btn btn-light border-dark mt-3" href="/blog">back to blog</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes_javan\dimas-aditya\resources\views/post.blade.php ENDPATH**/ ?>
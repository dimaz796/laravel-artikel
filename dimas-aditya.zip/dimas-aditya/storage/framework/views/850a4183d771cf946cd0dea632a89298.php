


<?php $__env->startSection('content'); ?>
    <h1>Halaman Blog</h1>
    <a href="/artikel/tambah">Tambah Artikel</a>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="mb-3 border border-2 rounded p-3">
            <h2><a href="/blog/<?php echo e($item->slug); ?>" class="text-decoration-none"><?php echo e($item->title); ?></a></h2>

            <h5>By <a class="text-decoration-none" href="#"><?php echo e($item->user->name); ?></a> In <a
                    class="text-decoration-none"
                    href="/categories/<?php echo e($item->category->slug); ?>"><?php echo e($item->category->name); ?></a>
            </h5>

            <p><?php echo e($item->excerpt); ?></p>

            <a href="/blog/<?php echo e($item->slug); ?>" class="text-decoration-none">Read More..</a>

        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes_javan\dimas-aditya\resources\views//blog.blade.php ENDPATH**/ ?>
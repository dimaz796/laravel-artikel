<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-light">
    <div class="container">
        <a class="navbar-brand" href="#">Navbar</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link <?php echo e($title === 'Home' ? 'active' : ''); ?>" href="/">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($title === 'Tentang Saya' ? 'active' : ''); ?>" href="/about">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e($title === 'Blog' ? 'active' : ''); ?>" href="/blog">Blog</a>
                </li>
                <li class="nav-item">
                    <?php if(auth()->guard()->guest()): ?>
                        <a class="nav-link" href="/login">Login</a>
                    <?php endif; ?>

                    <!-- Jika pengguna sudah login -->
                    <?php if(auth()->guard()->check()): ?>
                        <form id="logout-form" action="/logout" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                        <a class="nav-link" href="#"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
                    <?php endif; ?>
                </li>

            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\tes_javan\dimas-aditya\resources\views/partials/navbar.blade.php ENDPATH**/ ?>
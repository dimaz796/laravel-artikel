


<?php $__env->startSection('content'); ?>
    <h1>Halaman Kategori : <?php echo e($category); ?></h1>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="mb-3 border border-2 rounded p-3">
            <h2><a href="/blog/<?php echo e($item->slug); ?>"><?php echo e($item->title); ?></a></h2>
            <p><?php echo e($item->excerpt); ?></p>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes_javan\dimas-aditya\resources\views/category.blade.php ENDPATH**/ ?>
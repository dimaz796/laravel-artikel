

<?php $__env->startSection('content'); ?>
    <h1>Haii Selamat Datang</h1>
    <p><?php echo e($nama); ?></p>
    <p><?php echo e($email); ?></p>
    <img src="img/<?php echo e($foto); ?>" alt="" class="img-thumbnail rounded-circle w-25">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tes_javan\dimas-aditya\resources\views/about.blade.php ENDPATH**/ ?>